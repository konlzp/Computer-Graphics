SpiderGL.openNamespace();
