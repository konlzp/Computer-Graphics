System: MAC_OS_X
Browser: Safari

To avoid the triangles covering each other too much, I have restricted the size of the triangles, so that it would be more clear how many triangles are there in the canvas. (They are still random)
