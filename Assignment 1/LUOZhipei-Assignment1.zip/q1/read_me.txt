System: Mac_OS_X
Browser: Safari

For the "other" file, I used exponential to calculate the pixels and mod them to be under 256. And the file was basically adjusted upon the original sinewave file, so there may be some variable names are ambiguous. Sorry for that.
