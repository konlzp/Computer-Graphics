System: MAC_OS_X
Browser: Safari

I did a browser detection, where if the browser is safari or chrome, then some string manipulation would take place. So that the 'fakepath' issue could be avoided.

The effect of this filter is to smooth the given image, the larger the n and m, the smoothier the image is.

In the differenced image, we have the boundry pixels in the original images.
