System: MAC_OS_X
Browser: Safari

In the program, the user can identify the color they prefer, it will then make the color of the triangles more inclined to the color they prefer.

#########BE SURE TO CHECK OUT THE PROGRAM WHEN THE NUMBER OF TRIANGLES IS SET TO ZERO#########
